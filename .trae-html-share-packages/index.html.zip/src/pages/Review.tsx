import { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '@/store/memorizeStore';
import { dueWords, fmtInterval } from '@/utils/sm2';
import type { ReviewGrade } from '@/types';
import { Home, RotateCcw, Volume2 } from 'lucide-react';

export default function Review() {
  const words = useStore(s => s.words);
  const submitReview = useStore(s => s.submitReview);
  const navigate = useNavigate();

  const [queue, setQueue] = useState(() => dueWords(words));
  const [idx, setIdx] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [correctCount, setCorrectCount] = useState(0);
  const [againCount, setAgainCount] = useState(0);

  const reset = () => {
    setQueue(dueWords(useStore.getState().words));
    setIdx(0);
    setFlipped(false);
    setCorrectCount(0);
    setAgainCount(0);
  };

  // Re-compute when store updates (after a review submission)
  useEffect(() => {
    setQueue(dueWords(words));
    // Keep idx bounded
    if (idx >= dueWords(words).length) {
      // finish or show completed
    }
  }, [words]);

  const current = queue[idx];

  const handleRate = useCallback((grade: ReviewGrade) => {
    if (!current || !flipped) return;
    submitReview(current.id, grade);
    if (grade < 3) setAgainCount(v => v + 1);
    else setCorrectCount(v => v + 1);
    setFlipped(false);
    setIdx(i => i + 1);
  }, [current, flipped, submitReview]);

  // Keyboard shortcuts
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement;
      if (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA') return;
      if (!current) return;

      if (e.code === 'Space') {
        e.preventDefault();
        if (!flipped) setFlipped(true);
      } else if (flipped && ['1', '2', '3', '4'].includes(e.key)) {
        const grades: ReviewGrade[] = [0, 2, 4, 5];
        handleRate(grades[parseInt(e.key) - 1]);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [current, flipped, handleRate]);

  // Empty state
  if (queue.length === 0 || idx >= queue.length) {
    const total = correctCount + againCount;
    const acc = total > 0 ? Math.round((correctCount / total) * 100) : 0;
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
        <div className="text-[56px] mb-3">✨</div>
        <h2 className="text-[22px] font-semibold text-text mb-1">
          {total > 0 ? '今日复习完成！' : '没有待复习的单词'}
        </h2>
        <p className="text-text-sub mb-6">
          {total > 0
            ? `你完成了 ${total} 个单词的复习`
            : '明天再见，记得坚持哦～'}
        </p>

        {total > 0 && (
          <div className="flex gap-8 mb-6">
            <div>
              <div className="text-[32px] font-semibold text-primary leading-none">{correctCount}</div>
              <div className="text-[13px] text-text-sub mt-1">正确</div>
            </div>
            <div>
              <div className="text-[32px] font-semibold text-danger leading-none">{againCount}</div>
              <div className="text-[13px] text-text-sub mt-1">需要再来</div>
            </div>
            <div>
              <div className="text-[32px] font-semibold text-primary leading-none">{acc}%</div>
              <div className="text-[13px] text-text-sub mt-1">正确率</div>
            </div>
          </div>
        )}

        <div className="flex gap-3">
          <button
            onClick={() => navigate('/')}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-md border border-border-strong text-[13px] text-text hover:bg-surface-alt"
          >
            <Home size={15} /> 返回首页
          </button>
          <button
            onClick={reset}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-primary text-white text-[13px] font-semibold hover:bg-primary-hover shadow-card"
          >
            <RotateCcw size={15} /> 再来一轮
          </button>
        </div>
      </div>
    );
  }

  const progress = (idx / queue.length) * 100;

  return (
    <div className="flex flex-col items-center py-4">
      {/* Progress bar */}
      <div className="w-full max-w-[560px] h-1 bg-surface-alt rounded-full overflow-hidden mb-4">
        <div className="h-full bg-primary transition-all duration-300" style={{ width: `${progress}%` }} />
      </div>

      <div className="text-[13px] text-text-sub mb-6">
        第 <strong className="text-text">{idx + 1}</strong> / {queue.length} 个
      </div>

      {/* Flashcard */}
      <div className="perspective-[1200px] w-full max-w-[560px] h-[380px]">
        <div
          className={`relative w-full h-full transition-transform duration-500 ${flipped ? '[transform:rotateY(180deg)]' : ''}`}
          style={{ transformStyle: 'preserve-3d' }}
          onClick={() => setFlipped(v => !v)}
        >
          {/* Front */}
          <div
            className="absolute inset-0 rounded-lg shadow-card bg-surface border-none flex flex-col items-center justify-center p-8"
            style={{ backfaceVisibility: 'hidden' }}
          >
            <div className="text-[11px] uppercase tracking-[0.1em] text-text-muted mb-3 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-primary" />
              待复习
            </div>
            <div className="text-[52px] font-semibold text-text tracking-tight leading-none">
              {current.english}
            </div>
            <button
              onClick={e => { e.stopPropagation(); speak(current.english); }}
              className="mt-4 w-10 h-10 rounded-full bg-surface-alt text-text-sub hover:bg-primary-soft hover:text-primary transition-colors inline-flex items-center justify-center"
            >
              <Volume2 size={18} />
            </button>
            <div className="mt-auto text-[11px] text-text-muted">点击卡片翻面 · 空格</div>
          </div>

          {/* Back */}
          <div
            className="absolute inset-0 rounded-lg shadow-card bg-surface border-none flex flex-col items-center justify-center p-8"
            style={{
              backfaceVisibility: 'hidden',
              transform: 'rotateY(180deg)'
            }}
          >
            <div className="text-[11px] uppercase tracking-[0.1em] text-text-muted mb-3 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-primary" />
              {current.english}
            </div>
            {current.phonetic && (
              <div className="font-mono text-[18px] text-text-muted mb-1">{current.phonetic}</div>
            )}
            <div className="text-[22px] font-medium text-text text-center leading-snug">
              {current.chinese}
            </div>
            {current.example && (
              <div className="mt-5 px-4 py-3 bg-surface-alt rounded-md text-[13px] text-text-sub max-w-full text-center">
                <span className="text-text italic">"{current.example}"</span>
              </div>
            )}
            {current.tags.length > 0 && (
              <div className="mt-3 flex gap-1.5 flex-wrap justify-center">
                {current.tags.map(t => (
                  <span key={t} className="px-2.5 py-1 bg-surface-alt text-text-sub rounded-full text-[11px] font-medium">{t}</span>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Rating buttons */}
      <div
        className="flex gap-3 justify-center mt-6 w-full max-w-[560px] transition-all duration-300"
        style={{
          opacity: flipped ? 1 : 0,
          pointerEvents: flipped ? 'auto' : 'none'
        }}
      >
        {([
          { grade: 0, label: 'Again', cls: 'bg-red-50 text-red-600 hover:bg-red-100' },
          { grade: 2, label: 'Hard', cls: 'bg-amber-50 text-amber-700 hover:bg-amber-100' },
          { grade: 4, label: 'Good', cls: 'bg-primary-soft text-primary hover:bg-primary-soft/80' },
          { grade: 5, label: 'Easy', cls: 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100' }
        ] as const).map(r => (
          <button
            key={r.grade}
            onClick={() => handleRate(r.grade as ReviewGrade)}
            className={`flex-1 max-w-[120px] px-3 py-3.5 rounded-md text-[13px] font-semibold transition-colors flex flex-col gap-1 ${r.cls}`}
          >
            <span>{r.label}</span>
            <span className="text-[11px] font-normal opacity-70">
              {gradeInterval(current, r.grade)}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}

function gradeInterval(word: { easeFactor: number; interval: number; repetitions: number }, grade: number) {
  if (grade < 3) return '1 分钟';
  let { interval, repetitions } = word;
  if (repetitions === 0) interval = 1;
  else if (repetitions === 1) interval = 6;
  else interval = Math.round(interval * word.easeFactor);
  return fmtInterval(interval);
}

function speak(text: string) {
  if ('speechSynthesis' in window) {
    const u = new SpeechSynthesisUtterance(text);
    u.lang = 'en-US';
    u.rate = 0.9;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
  }
}
