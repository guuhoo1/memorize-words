import { useParams, useNavigate } from 'react-router-dom';
import { useStore } from '@/store/memorizeStore';
import { ArrowLeft, Check, BookOpen } from 'lucide-react';

export default function DialogueDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const dialogues = useStore(s => s.dialogues);
  const words = useStore(s => s.words);

  const d = dialogues.find(x => x.id === id);

  if (!d) {
    return (
      <div className="text-center py-20">
        <p className="text-text-sub mb-4">对话不存在</p>
        <button
          onClick={() => navigate('/dialogues')}
          className="text-primary hover:underline"
        >
          返回对话集
        </button>
      </div>
    );
  }

  const linkedWords = d.wordIds
    .map(wid => words.find(w => w.id === wid))
    .filter(Boolean);

  return (
    <div className="max-w-[680px] mx-auto">
      <button
        onClick={() => navigate('/dialogues')}
        className="inline-flex items-center gap-1.5 text-[13px] text-text-sub hover:text-text mb-4"
      >
        <ArrowLeft size={15} /> 返回对话集
      </button>

      <div className="bg-surface rounded-lg shadow-card overflow-hidden">
        <div className="px-6 py-5 border-b border-border">
          <div className="text-[11px] uppercase tracking-wider text-text-muted font-semibold mb-1.5">
            {d.source ?? d.category} · {d.category}
          </div>
          <h1 className="text-[22px] font-semibold text-text leading-tight">{d.title}</h1>
          <div className="mt-2 text-[13px] text-text-muted">
            更新于 {new Date(d.updatedAt).toLocaleDateString('zh-CN')}
          </div>
        </div>

        <div className="p-6">
          <pre className="font-sans text-[14px] leading-[1.9] text-text whitespace-pre-wrap bg-surface-alt p-5 rounded-md">
            {d.content}
          </pre>
        </div>

        {linkedWords.length > 0 && (
          <div className="px-6 pb-6">
            <div className="text-[13px] font-semibold text-text-sub mb-3 uppercase tracking-wide">
              关联生词 ({linkedWords.length})
            </div>
            <div className="flex flex-wrap gap-2">
              {linkedWords.map(w => (
                <span
                  key={w!.id}
                  className="inline-flex items-center gap-1.5 px-3 py-1 bg-primary-soft text-primary-hover rounded-full text-[13px] cursor-pointer hover:bg-primary-soft/80"
                  onClick={() => navigate(`/words/${w!.id}`)}
                >
                  <Check size={13} />
                  {w!.english} — {w!.chinese}
                </span>
              ))}
            </div>
          </div>
        )}

        <div className="px-6 pb-6 pt-2">
          <button
            onClick={() => navigate('/words/new')}
            className="inline-flex items-center gap-2 text-[13px] text-primary hover:underline"
          >
            <BookOpen size={14} /> 在此对话中添加新单词
          </button>
        </div>
      </div>
    </div>
  );
}
