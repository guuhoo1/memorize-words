import { useRef } from 'react';
import { useStore } from '@/store/memorizeStore';
import { downloadJSON } from '@/utils/storage';
import { Upload, Download, Trash2 } from 'lucide-react';

export default function Settings() {
  const words = useStore(s => s.words);
  const dialogues = useStore(s => s.dialogues);
  const resetAll = useStore(s => s.resetAll);
  const fileRef = useRef<HTMLInputElement>(null);

  const exportData = () => {
    downloadJSON({ words, dialogues }, `memorize-backup-${Date.now()}.json`);
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    try {
      const text = await f.text();
      const data = JSON.parse(text);
      if (data.words || data.dialogues) {
        alert('导入功能即将上线（后续 Phase 实现）');
      } else {
        alert('文件格式不正确');
      }
    } catch {
      alert('解析失败，请确认是 JSON 文件');
    }
    e.target.value = '';
  };

  return (
    <div className="max-w-[600px]">
      <h1 className="text-[28px] font-semibold tracking-tight mb-6">设置</h1>

      {/* Data section */}
      <section className="bg-surface rounded-lg shadow-card p-6 mb-4">
        <h2 className="text-[13px] font-semibold text-text-sub uppercase tracking-wide mb-4">数据管理</h2>

        <div className="flex items-center justify-between py-3 border-b border-border last:border-0">
          <div>
            <div className="text-[14px] font-medium text-text">导出数据</div>
            <div className="text-[12px] text-text-sub mt-0.5">备份所有单词和对话到 JSON 文件</div>
          </div>
          <button
            onClick={exportData}
            className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-md border border-border-strong text-[13px] text-text hover:bg-surface-alt"
          >
            <Download size={14} /> 导出
          </button>
        </div>

        <div className="flex items-center justify-between py-3 border-b border-border">
          <div>
            <div className="text-[14px] font-medium text-text">导入数据</div>
            <div className="text-[12px] text-text-sub mt-0.5">从 JSON 备份文件恢复</div>
          </div>
          <button
            onClick={() => fileRef.current?.click()}
            className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-md border border-border-strong text-[13px] text-text hover:bg-surface-alt"
          >
            <Upload size={14} /> 导入
          </button>
          <input ref={fileRef} type="file" accept="application/json" onChange={handleImport} className="hidden" />
        </div>

        <div className="flex items-center justify-between py-3">
          <div>
            <div className="text-[14px] font-medium text-text">清空所有数据</div>
            <div className="text-[12px] text-text-sub mt-0.5">删除所有单词、对话和复习记录（不可恢复）</div>
          </div>
          <button
            onClick={() => {
              if (confirm('确定要清空所有数据吗？此操作不可恢复。')) {
                resetAll();
              }
            }}
            className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-md text-[13px] bg-red-50 text-danger hover:bg-red-100"
          >
            <Trash2 size={14} /> 清空
          </button>
        </div>
      </section>

      {/* About */}
      <section className="bg-surface rounded-lg shadow-card p-6">
        <h2 className="text-[13px] font-semibold text-text-sub uppercase tracking-wide mb-4">关于</h2>
        <div className="text-[13px] text-text-sub space-y-1">
          <p>Memorize · 记单词 & 记对话 v0.1</p>
          <p>基于 SM-2 间隔重复算法</p>
          <p>数据存储于浏览器 localStorage · 可离线使用</p>
        </div>
      </section>
    </div>
  );
}
