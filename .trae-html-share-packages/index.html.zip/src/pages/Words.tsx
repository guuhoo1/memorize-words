import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '@/store/memorizeStore';
import { Search, Plus, Trash2, Play } from 'lucide-react';

export default function Words() {
  const words = useStore(s => s.words);
  const deleteWord = useStore(s => s.deleteWord);
  const navigate = useNavigate();

  const [search, setSearch] = useState('');
  const [tag, setTag] = useState<string>('');

  const allTags = useMemo(() => {
    const s = new Set<string>();
    words.forEach(w => w.tags.forEach(t => s.add(t)));
    return [...s];
  }, [words]);

  const filtered = useMemo(() => {
    let list = words;
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(w =>
        w.english.toLowerCase().includes(q) ||
        w.chinese.includes(search)
      );
    }
    if (tag) list = list.filter(w => w.tags.includes(tag));
    return list;
  }, [words, search, tag]);

  return (
    <div>
      <div className="flex items-end justify-between mb-7">
        <div>
          <h1 className="text-[28px] font-semibold tracking-tight text-text">单词本</h1>
          <p className="text-[13px] text-text-sub mt-0.5">
            共 <strong>{filtered.length}</strong> 个单词 {tag && `· 筛选: ${tag}`}
          </p>
        </div>
        <button
          onClick={() => navigate('/words/new')}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-primary hover:bg-primary-hover text-white text-[13px] font-semibold shadow-card transition-all"
        >
          <Plus size={15} />
          添加单词
        </button>
      </div>

      {/* Tag chips */}
      {allTags.length > 0 && (
        <div className="flex gap-2 mb-4 flex-wrap items-center">
          <span className="text-[11px] text-text-muted uppercase tracking-wider font-semibold mr-1">标签</span>
          <button
            onClick={() => setTag('')}
            className={`px-2.5 py-1 rounded-full text-[12px] font-medium transition-colors ${
              !tag ? 'bg-primary-soft text-primary-hover' : 'bg-surface-alt text-text-sub hover:bg-surface-hover'
            }`}
          >
            全部
          </button>
          {allTags.map(t => (
            <button
              key={t}
              onClick={() => setTag(t === tag ? '' : t)}
              className={`px-2.5 py-1 rounded-full text-[12px] font-medium transition-colors ${
                t === tag ? 'bg-primary-soft text-primary-hover' : 'bg-surface-alt text-text-sub hover:text-text'
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      )}

      {/* Table */}
      <div className="bg-surface rounded-lg shadow-card overflow-hidden">
        {/* Toolbar */}
        <div className="flex items-center justify-between px-6 py-3 border-b border-border">
          <div className="relative flex-1 max-w-[360px]">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="搜索单词或释义..."
              className="w-full pl-9 pr-3 py-2 border border-border rounded-md bg-surface-alt text-[13px] text-text focus:outline-none focus:border-primary focus:bg-surface"
            />
          </div>
        </div>

        <table className="w-full">
          <thead>
            <tr className="text-left text-[11px] font-semibold text-text-muted uppercase tracking-wider">
              <th className="px-6 py-3 w-[28%]">单词</th>
              <th className="px-6 py-3">释义</th>
              <th className="px-6 py-3">标签</th>
              <th className="px-6 py-3 w-[100px]">状态</th>
              <th className="px-6 py-3 w-[110px]">下次复习</th>
              <th className="px-6 py-3 w-[40px]" />
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr>
                <td colSpan={6} className="px-6 py-16 text-center text-text-muted text-[13px]">
                  没有找到匹配的单词
                </td>
              </tr>
            )}
            {filtered.map(w => (
              <tr
                key={w.id}
                className="border-t border-border hover:bg-surface-alt/50 cursor-pointer group"
                onClick={() => navigate(`/words/${w.id}`)}
              >
                <td className="px-6 py-3.5">
                  <div className="flex items-center gap-2">
                    <div>
                      <div className="font-semibold text-[18px] text-text">{w.english}</div>
                      {w.phonetic && (
                        <div className="font-mono text-[12px] text-text-muted mt-0.5">{w.phonetic}</div>
                      )}
                    </div>
                    <button
                      onClick={e => { e.stopPropagation(); speak(w.english); }}
                      className="opacity-0 group-hover:opacity-100 transition-opacity w-7 h-7 rounded-full bg-surface-alt text-text-muted hover:text-primary inline-flex items-center justify-center"
                    >
                      <Play size={13} fill="currentColor" />
                    </button>
                  </div>
                </td>
                <td className="px-6 py-3.5 text-text-sub text-[13px]">{w.chinese}</td>
                <td className="px-6 py-3.5">
                  <div className="flex gap-1.5 flex-wrap">
                    {w.tags.map(t => (
                      <span key={t} className="px-2 py-0.5 bg-surface-alt rounded-full text-[11px] font-medium text-text-sub">{t}</span>
                    ))}
                  </div>
                </td>
                <td className="px-6 py-3.5">
                  <WordStatus repetitions={w.repetitions} />
                </td>
                <td className="px-6 py-3.5 text-[13px] text-text-sub">{formatDue(w.nextReview)}</td>
                <td className="px-6 py-3.5">
                  <button
                    onClick={e => {
                      e.stopPropagation();
                      if (confirm(`确定删除 "${w.english}"？`)) deleteWord(w.id);
                    }}
                    className="opacity-0 group-hover:opacity-100 transition-opacity p-1.5 rounded-sm text-text-muted hover:text-danger hover:bg-red-50"
                  >
                    <Trash2 size={14} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function WordStatus({ repetitions }: { repetitions: number }) {
  const config = [
    { label: '新词', cls: 'bg-text-muted' },
    { label: '学习中', cls: 'bg-warning' },
    { label: '复习中', cls: 'bg-primary' },
    { label: '已掌握', cls: 'bg-info' }
  ];
  const idx = repetitions === 0 ? 0 : repetitions < 3 ? 1 : repetitions < 5 ? 2 : 3;
  const c = config[idx];
  return (
    <span className="inline-flex items-center gap-1.5 text-[13px] text-text-sub">
      <span className={`inline-block w-2 h-2 rounded-full ${c.cls}`} />
      {c.label}
    </span>
  );
}

function formatDue(ts: number) {
  const diff = Math.ceil((ts - Date.now()) / 86400000);
  if (diff < 0) return <span className="text-danger">已到期</span>;
  if (diff === 0) return <span className="text-warning">今天</span>;
  return `${diff} 天后`;
}

function speak(text: string) {
  if ('speechSynthesis' in window) {
    const u = new SpeechSynthesisUtterance(text);
    u.lang = 'en-US';
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
  }
}
