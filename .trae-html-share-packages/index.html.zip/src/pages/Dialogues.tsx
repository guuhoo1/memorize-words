import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '@/store/memorizeStore';
import type { DialogueCategory } from '@/types';
import { Plus, FileText } from 'lucide-react';

const CATEGORIES: DialogueCategory[] = ['电影/剧集', '书籍', '演讲', '日常/工作'];

export default function Dialogues() {
  const dialogues = useStore(s => s.dialogues);
  const addDialogue = useStore(s => s.addDialogue);
  const navigate = useNavigate();

  const [showModal, setShowModal] = useState(false);
  const [category, setCategory] = useState<DialogueCategory | ''>('');

  // Form state
  const [title, setTitle] = useState('');
  const [source, setSource] = useState('');
  const [selCategory, setSelCategory] = useState<DialogueCategory>('电影/剧集');
  const [content, setContent] = useState('');

  const filtered = category
    ? dialogues.filter(d => d.category === category)
    : dialogues;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;
    addDialogue({ title, source, category: selCategory, content });
    setTitle(''); setSource(''); setContent(''); setShowModal(false);
  };

  return (
    <div>
      <div className="flex items-end justify-between mb-7">
        <div>
          <h1 className="text-[28px] font-semibold tracking-tight text-text">对话集</h1>
          <p className="text-[13px] text-text-sub mt-0.5">
            共 <strong>{dialogues.length}</strong> 段素材
          </p>
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-primary hover:bg-primary-hover text-white text-[13px] font-semibold shadow-card transition-all"
        >
          <Plus size={15} />
          添加对话
        </button>
      </div>

      {/* Category filter */}
      <div className="flex gap-2 mb-6">
        <FilterBtn active={category === ''} onClick={() => setCategory('')}>全部</FilterBtn>
        {CATEGORIES.map(c => (
          <FilterBtn key={c} active={category === c} onClick={() => setCategory(c)}>{c}</FilterBtn>
        ))}
      </div>

      {/* Grid */}
      {filtered.length === 0 ? (
        <div className="bg-surface rounded-lg shadow-card p-16 text-center">
          <FileText size={56} className="mx-auto mb-4 text-text-muted" />
          <div className="text-[18px] font-semibold text-text mb-1">还没有对话素材</div>
          <div className="text-[13px] text-text-sub">粘贴电影台词、书籍段落或日常对话来积累素材</div>
        </div>
      ) : (
        <div className="grid grid-cols-[repeat(auto-fill,minmax(320px,1fr))] gap-4">
          {filtered.map(d => {
            const preview = d.content.split('\n').filter(Boolean)[0] || '';
            const date = new Date(d.updatedAt).toLocaleDateString('zh-CN');
            return (
              <button
                key={d.id}
                onClick={() => navigate(`/dialogues/${d.id}`)}
                className="bg-surface rounded-lg shadow-card p-5 text-left transition-all hover:shadow-card-hover hover:-translate-y-0.5 group"
              >
                <div className="text-[11px] uppercase tracking-wider text-text-muted font-semibold">
                  {d.source ?? d.category}
                </div>
                <div className="mt-1.5 text-[18px] font-semibold text-text leading-tight">
                  {d.title}
                </div>
                <div className="mt-3 text-[13px] text-text-sub leading-relaxed line-clamp-3">
                  {preview.length > 80 ? preview.slice(0, 80) + '...' : preview}
                </div>
                <div className="mt-4 pt-3 border-t border-border flex justify-between text-[11px] text-text-muted">
                  <span>📅 {date}</span>
                  <span>🔗 {d.wordIds.length} 个关联生词</span>
                </div>
              </button>
            );
          })}
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <div
          className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 animate-[fadeIn_0.25s_ease-out]"
          onClick={() => setShowModal(false)}
        >
          <div
            className="bg-surface rounded-lg shadow-[0_12px_48px_rgba(15,15,30,0.2)] w-full max-w-[520px] max-h-[85vh] overflow-auto"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex justify-between items-center px-6 py-4 border-b border-border">
              <h3 className="text-[18px] font-semibold">添加对话素材</h3>
              <button
                onClick={() => setShowModal(false)}
                className="w-8 h-8 rounded-sm text-text-sub hover:bg-surface-alt inline-flex items-center justify-center"
              >
                ✕
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <label className="block">
                <span className="block text-[13px] font-medium text-text mb-1.5">标题 *</span>
                <input
                  type="text"
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  className="w-full px-3 py-2 border border-border rounded-md bg-bg text-[14px] focus:outline-none focus:border-primary focus:bg-surface"
                  placeholder="例如: Friends S01E01 · 咖啡馆偶遇"
                  required
                />
              </label>
              <div className="grid grid-cols-2 gap-4">
                <label className="block">
                  <span className="block text-[13px] font-medium text-text mb-1.5">来源</span>
                  <input
                    type="text"
                    value={source}
                    onChange={e => setSource(e.target.value)}
                    className="w-full px-3 py-2 border border-border rounded-md bg-bg text-[14px] focus:outline-none focus:border-primary focus:bg-surface"
                    placeholder="Friends 老友记"
                  />
                </label>
                <label className="block">
                  <span className="block text-[13px] font-medium text-text mb-1.5">分类</span>
                  <select
                    value={selCategory}
                    onChange={e => setSelCategory(e.target.value as DialogueCategory)}
                    className="w-full px-3 py-2 border border-border rounded-md bg-bg text-[14px] focus:outline-none focus:border-primary focus:bg-surface"
                  >
                    {CATEGORIES.map(c => <option key={c}>{c}</option>)}
                  </select>
                </label>
              </div>
              <label className="block">
                <span className="block text-[13px] font-medium text-text mb-1.5">对话内容 *</span>
                <textarea
                  value={content}
                  onChange={e => setContent(e.target.value)}
                  rows={7}
                  className="w-full px-3 py-2 border border-border rounded-md bg-bg text-[14px] focus:outline-none focus:border-primary focus:bg-surface resize-none"
                  placeholder="粘贴或输入对话文本..."
                  required
                />
              </label>
              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 rounded-md border border-border-strong text-[13px] text-text hover:bg-surface-alt"
                >
                  取消
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-md bg-primary hover:bg-primary-hover text-white text-[13px] font-semibold shadow-card"
                >
                  保存
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

function FilterBtn({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`px-2.5 py-1 rounded-full text-[12px] font-medium transition-colors ${
        active ? 'bg-primary-soft text-primary-hover' : 'bg-surface-alt text-text-sub hover:text-text'
      }`}
    >
      {children}
    </button>
  );
}
