import { useNavigate } from 'react-router-dom';
import { useStore } from '@/store/memorizeStore';
import { dueWords } from '@/utils/sm2';
import { Play, Plus, ArrowRight, FileText } from 'lucide-react';

export default function Dashboard() {
  const words = useStore(s => s.words);
  const dialogues = useStore(s => s.dialogues);
  const navigate = useNavigate();

  const due = dueWords(words);
  const mastered = words.filter(w => w.repetitions >= 4).length;

  const recentWords = [...words]
    .sort((a, b) => b.createdAt - a.createdAt)
    .slice(0, 5);

  return (
    <div className="animate-[fadeUp_0.5s_ease-out]">
      {/* Page header */}
      <div className="flex items-end justify-between mb-7">
        <div>
          <h1 className="text-[28px] font-semibold tracking-tight text-text">
            下午好，Alex
          </h1>
          <p className="text-[13px] text-text-sub mt-0.5">
            今天有 <strong className="text-primary">{due.length}</strong> 个单词等你复习
          </p>
        </div>
        <button
          onClick={() => navigate('/review')}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-md bg-primary hover:bg-primary-hover text-white text-[14px] font-semibold shadow-card transition-all"
        >
          <Play size={16} fill="currentColor" />
          开始今日复习
        </button>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-4 gap-3 mb-6">
        <StatCard label="累计单词" value={words.length} suffix="个" />
        <StatCard label="今日待复习" value={due.length} suffix="个" accent="text-warning" />
        <StatCard label="已掌握" value={mastered} suffix="个" accent="text-primary" />
        <StatCard label="对话素材" value={dialogues.length} suffix="段" />
      </div>

      {/* Two column */}
      <div className="grid grid-cols-[2fr_1fr] gap-5 mb-6">
        {/* Heatmap card */}
        <div className="bg-surface rounded-lg shadow-card p-5">
          <div className="flex justify-between items-center mb-3">
            <div className="text-[13px] font-semibold text-text-sub uppercase tracking-wide">
              学习热力图
            </div>
            <span className="px-2.5 py-1 bg-primary-soft text-primary-hover rounded-full text-[11px] font-medium">
              过去一年
            </span>
          </div>
          <Heatmap />
        </div>

        {/* Quick actions */}
        <div className="bg-surface rounded-lg shadow-card p-5">
          <div className="text-[13px] font-semibold text-text-sub uppercase tracking-wide mb-3">
            快速操作
          </div>
          <div className="flex flex-col gap-2">
            <QuickBtn icon={Plus} label="添加新单词" onClick={() => navigate('/words/new')} />
          <QuickBtn icon={FileText} label="对话集" onClick={() => navigate('/dialogues')} />
          </div>
        </div>
      </div>

      {/* Recent words */}
      <div className="bg-surface rounded-lg shadow-card overflow-hidden">
        <div className="flex justify-between items-center px-6 py-3 border-b border-border">
          <div className="text-[13px] font-semibold text-text-sub uppercase tracking-wide">
            最近添加的单词
          </div>
          <button
            onClick={() => navigate('/words')}
            className="text-[13px] text-text-sub hover:text-primary inline-flex items-center gap-1"
          >
            查看全部 <ArrowRight size={14} />
          </button>
        </div>
        <table className="w-full">
          <thead>
            <tr className="text-left text-[11px] font-semibold text-text-muted uppercase tracking-wider">
              <th className="px-6 py-3 w-[40%]">单词</th>
              <th className="px-6 py-3">释义</th>
              <th className="px-6 py-3 w-[100px]">状态</th>
              <th className="px-6 py-3 w-[110px]">下次复习</th>
            </tr>
          </thead>
          <tbody>
            {recentWords.map(w => (
              <tr key={w.id} className="border-t border-border hover:bg-surface-alt/50 cursor-pointer"
                  onClick={() => navigate(`/words/${w.id}`)}>
                <td className="px-6 py-3.5">
                  <div className="font-semibold text-[18px] text-text">{w.english}</div>
                  {w.phonetic && (
                    <div className="font-mono text-[12px] text-text-muted mt-0.5">{w.phonetic}</div>
                  )}
                </td>
                <td className="px-6 py-3.5 text-text-sub">{w.chinese}</td>
                <td className="px-6 py-3.5">
                  <WordStatus repetitions={w.repetitions} />
                </td>
                <td className="px-6 py-3.5 text-[13px] text-text-sub">
                  {formatDue(w.nextReview)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function StatCard({ label, value, suffix, accent }: {
  label: string; value: number; suffix?: string; accent?: string;
}) {
  return (
    <div className="bg-surface rounded-lg shadow-card p-5">
      <div className="text-[13px] text-text-sub font-medium">{label}</div>
      <div className={`font-semibold tracking-tight leading-none mt-2 ${accent ?? 'text-text'}`}
           style={{ fontSize: '36px', fontFamily: 'inherit' }}>
        {value}
        {suffix && <span className="text-[13px] text-text-muted ml-1.5 font-normal">{suffix}</span>}
      </div>
    </div>
  );
}

function WordStatus({ repetitions }: { repetitions: number }) {
  const config = [
    { label: '新词', cls: 'bg-text-muted' },
    { label: '学习中', cls: 'bg-warning' },
    { label: '复习中', cls: 'bg-primary' },
    { label: '已掌握', cls: 'bg-info' }
  ];
  const idx = repetitions === 0 ? 0 : repetitions < 3 ? 1 : repetitions < 5 ? 2 : 3;
  const c = config[idx];
  return (
    <span className="inline-flex items-center gap-1.5 text-[13px] text-text-sub">
      <span className={`inline-block w-2 h-2 rounded-full ${c.cls}`} />
      {c.label}
    </span>
  );
}

function formatDue(ts: number) {
  const diff = Math.ceil((ts - Date.now()) / 86400000);
  if (diff < 0) return <span className="text-danger">已到期</span>;
  if (diff === 0) return <span className="text-warning">今天</span>;
  return `${diff} 天后`;
}

function QuickBtn({ icon: Icon, label, onClick }: any) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-2.5 px-3 py-2 rounded-sm text-[13px] text-text-sub hover:bg-surface-alt hover:text-text transition-colors text-left"
    >
      <Icon size={16} />
      <span>{label}</span>
    </button>
  );
}

function Heatmap() {
  // Generate deterministic heatmap (52 weeks × 7 days)
  const cells: number[] = [];
  for (let w = 0; w < 52; w++) {
    for (let d = 0; d < 7; d++) {
      const base = Math.random();
      let level = 0;
      if (w > 30) {
        level = base < 0.35 ? 0 : base < 0.65 ? 1 : base < 0.85 ? 2 : base < 0.96 ? 3 : 4;
      } else {
        level = base < 0.55 ? 0 : base < 0.82 ? 1 : base < 0.95 ? 2 : 3;
      }
      cells.push(level);
    }
  }
  const shades = ['bg-surface-alt', 'bg-primary/25', 'bg-primary/50', 'bg-primary/75', 'bg-primary'];
  return (
    <>
      <div className="grid grid-flow-col gap-[3px]" style={{ gridTemplateRows: 'repeat(7, minmax(0,1fr))' }}>
        {cells.map((lvl, i) => (
          <div key={i} className={`w-full aspect-square rounded-[3px] ${shades[lvl]} transition-transform hover:scale-[1.3]`} />
        ))}
      </div>
      <div className="flex items-center gap-2 mt-3 text-[11px] text-text-muted">
        少
        {shades.map((s, i) => (
          <span key={i} className={`w-3 h-3 rounded-[3px] ${s}`} />
        ))}
        多
      </div>
    </>
  );
}
