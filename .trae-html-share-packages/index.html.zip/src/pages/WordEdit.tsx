import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useStore } from '@/store/memorizeStore';
import { ArrowLeft } from 'lucide-react';

export default function WordEdit() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const words = useStore(s => s.words);
  const addWord = useStore(s => s.addWord);
  const updateWord = useStore(s => s.updateWord);

  const existing = id ? words.find(w => w.id === id) : undefined;
  const isEdit = !!existing;

  const [english, setEnglish] = useState(existing?.english ?? '');
  const [chinese, setChinese] = useState(existing?.chinese ?? '');
  const [phonetic, setPhonetic] = useState(existing?.phonetic ?? '');
  const [example, setExample] = useState(existing?.example ?? '');
  const [tagsInput, setTagsInput] = useState(existing?.tags.join(', ') ?? '');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!english.trim() || !chinese.trim()) return;

    const tags = tagsInput.split(',').map(s => s.trim()).filter(Boolean);

    if (isEdit && existing) {
      updateWord(existing.id, { english, chinese, phonetic, example, tags });
    } else {
      addWord({ english, chinese, phonetic, example, tags });
    }
    navigate('/words');
  };

  return (
    <div className="max-w-[600px] mx-auto">
      <button
        onClick={() => navigate('/words')}
        className="inline-flex items-center gap-1.5 text-[13px] text-text-sub hover:text-text mb-4"
      >
        <ArrowLeft size={15} /> 返回单词本
      </button>

      <h1 className="text-[28px] font-semibold tracking-tight mb-6">
        {isEdit ? '编辑单词' : '添加新单词'}
      </h1>

      <form onSubmit={handleSubmit} className="bg-surface rounded-lg shadow-card p-6 space-y-4">
        <Field label="英文 *">
          <input
            type="text"
            value={english}
            onChange={e => setEnglish(e.target.value)}
            placeholder="例如: serendipity"
            className="w-full px-3 py-2 border border-border rounded-md bg-bg text-[14px] text-text focus:outline-none focus:border-primary focus:bg-surface"
            required
          />
        </Field>

        <Field label="中文释义 *">
          <input
            type="text"
            value={chinese}
            onChange={e => setChinese(e.target.value)}
            placeholder="意外发现美好事物的运气"
            className="w-full px-3 py-2 border border-border rounded-md bg-bg text-[14px] text-text focus:outline-none focus:border-primary focus:bg-surface"
            required
          />
        </Field>

        <div className="grid grid-cols-2 gap-4">
          <Field label="音标">
            <input
              type="text"
              value={phonetic}
              onChange={e => setPhonetic(e.target.value)}
              placeholder="/ˌserənˈdɪpəti/"
              className="w-full px-3 py-2 border border-border rounded-md bg-bg text-[14px] font-mono text-text focus:outline-none focus:border-primary focus:bg-surface"
            />
          </Field>
          <Field label="标签 (逗号分隔)">
            <input
              type="text"
              value={tagsInput}
              onChange={e => setTagsInput(e.target.value)}
              placeholder="雅思, 电影台词"
              className="w-full px-3 py-2 border border-border rounded-md bg-bg text-[14px] text-text focus:outline-none focus:border-primary focus:bg-surface"
            />
          </Field>
        </div>

        <Field label="例句">
          <textarea
            value={example}
            onChange={e => setExample(e.target.value)}
            rows={3}
            placeholder="英文例句，帮助理解语境..."
            className="w-full px-3 py-2 border border-border rounded-md bg-bg text-[14px] text-text focus:outline-none focus:border-primary focus:bg-surface resize-none"
          />
        </Field>

        <div className="flex justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={() => navigate('/words')}
            className="px-4 py-2 rounded-md border border-border-strong text-[13px] text-text hover:bg-surface-alt"
          >
            取消
          </button>
          <button
            type="submit"
            className="px-5 py-2 rounded-md bg-primary hover:bg-primary-hover text-white text-[13px] font-semibold shadow-card"
          >
            {isEdit ? '保存修改' : '添加'}
          </button>
        </div>
      </form>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="block text-[13px] font-medium text-text mb-1.5">{label}</span>
      {children}
    </label>
  );
}
