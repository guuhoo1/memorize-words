import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useStore } from '@/store/memorizeStore';
import { dueWords } from '@/utils/sm2';
import {
  BookOpen,
  FileText,
  CalendarCheck,
  Home,
  Settings
} from 'lucide-react';

const navItems = [
  { to: '/', icon: Home, label: '首页' },
  { to: '/review', icon: CalendarCheck, label: '今日复习', badge: true },
  { to: '/words', icon: BookOpen, label: '单词本' },
  { to: '/dialogues', icon: FileText, label: '对话集' }
];

export default function Layout() {
  const words = useStore(s => s.words);
  const dialogues = useStore(s => s.dialogues);
  const navigate = useNavigate();
  const due = dueWords(words).length;

  return (
    <div className="flex min-h-screen bg-bg">
      {/* Sidebar */}
      <aside className="fixed inset-y-0 left-0 w-[200px] bg-surface border-r border-border flex flex-col py-6 px-4 z-10">
        {/* Brand */}
        <div className="flex items-center gap-2 pb-5 mb-3 border-b border-border px-2">
          <div className="w-9 h-9 rounded-md bg-primary-soft flex items-center justify-center">
            <BookOpen size={18} className="text-primary" />
          </div>
          <div>
            <div className="font-semibold text-[16px] text-text leading-tight">Memorize</div>
            <div className="text-[11px] text-text-muted">记单词 · 记对话</div>
          </div>
        </div>

        {/* Stats (sidebar footer info) */}
        <div className="text-[11px] text-text-muted px-2 mb-2 uppercase tracking-wider font-semibold">
          概览
        </div>

        {/* Nav */}
        <nav className="flex flex-col gap-0.5">
          {navItems.map(item => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === '/'}
                className={({ isActive }) =>
                  [
                    'flex items-center gap-2.5 px-3 py-2 rounded-sm text-[13px] font-medium transition-colors',
                    isActive
                      ? 'bg-surface-alt text-text font-semibold'
                      : 'text-text-sub hover:bg-surface-alt hover:text-text'
                  ].join(' ')
                }
              >
                {({ isActive }) => (
                  <>
                    <span className="absolute left-0 w-[2px] h-4 rounded bg-primary transition-opacity"
                          style={{ opacity: isActive ? 1 : 0 }} />
                    <Icon size={16} />
                    <span>{item.label}</span>
                    {item.badge && due > 0 && (
                      <span className="ml-auto bg-primary text-white text-[11px] font-semibold px-[7px] py-[2px] rounded-[10px] leading-none">
                        {due}
                      </span>
                    )}
                  </>
                )}
              </NavLink>
            );
          })}
        </nav>

        {/* Sidebar stats */}
        <div className="mt-auto pt-4 border-t border-border text-[11px] text-text-muted px-2 space-y-1">
          <div className="flex justify-between">
            <span>单词</span><span className="text-text-sub">{words.length}</span>
          </div>
          <div className="flex justify-between">
            <span>对话</span><span className="text-text-sub">{dialogues.length}</span>
          </div>
        </div>

        <button
          onClick={() => navigate('/settings')}
          className="mt-3 flex items-center gap-2.5 px-3 py-2 rounded-sm text-[13px] font-medium text-text-sub hover:bg-surface-alt hover:text-text transition-colors"
        >
          <Settings size={16} />
          <span>设置</span>
        </button>
      </aside>

      {/* Main */}
      <main className="ml-[200px] flex-1 px-10 py-8 max-w-full">
        <Outlet />
      </main>
    </div>
  );
}
