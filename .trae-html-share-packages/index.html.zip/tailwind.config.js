/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#5B5BFF',
          hover: '#4A4AEB',
          soft: '#EDEDFB'
        },
        surface: {
          DEFAULT: '#FFFFFF',
          alt: '#F2F2F4'
        },
        bg: '#F7F7F8',
        border: {
          DEFAULT: '#ECECF0',
          strong: '#DCDCE2'
        },
        text: {
          DEFAULT: '#0B0B10',
          sub: '#6B6B76',
          muted: '#9A9AA3'
        }
      },
      fontFamily: {
        sans: [
          '-apple-system', 'BlinkMacSystemFont', 'Inter', 'Segoe UI',
          'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', 'sans-serif'
        ]
      },
      boxShadow: {
        card: '0 8px 24px rgba(15,15,30,0.08), 0 2px 6px rgba(15,15,30,0.04)',
        'card-hover': '0 12px 32px rgba(15,15,30,0.12)'
      },
      borderRadius: {
        sm: '4px',
        md: '6px',
        lg: '8px'
      }
    }
  },
  plugins: []
};
